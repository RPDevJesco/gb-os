RP2040 Bootloader
=================

NOTE: This is a placeholder build. Stage2 flash init required.

The RP2040 boot chain:
1. Boot ROM loads 256-byte stage2 from flash
2. Stage2 configures XIP (execute-in-place)
3. Main application runs from flash

To flash:
1. Hold BOOTSEL button while connecting USB
2. Copy UF2 file to mounted drive
