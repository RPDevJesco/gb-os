Raspberry Pi 5 Bootloader
=========================

NOTE: This is a placeholder build. Pi 5 support is incomplete.

The Pi 5 uses different:
- Peripheral base addresses
- RP1 southbridge for I/O
- Boot firmware chain

Full implementation requires hardware testing.
