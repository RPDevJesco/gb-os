KickPi K2B (Allwinner H618) Bootloader
======================================

NOTE: This is a placeholder build. DRAM initialization required.

The H618 boot chain:
1. BROM loads boot0 from SD offset 8KB
2. boot0 initializes DRAM
3. boot0 loads U-Boot or payload to DRAM

Flashing to SD card:
  sudo dd if=boot0.bin of=/dev/sdX bs=1024 seek=8
