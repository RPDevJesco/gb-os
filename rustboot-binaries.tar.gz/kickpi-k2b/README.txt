KickPi K2B (Allwinner H618) Bootloader
======================================

NOTE: This is a placeholder build. DRAM initialization required.

The H618 boot chain requires complex initialization.
