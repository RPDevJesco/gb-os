Raspberry Pi Zero 2 W Bootloader
================================

Files:
  kernel8.img  - Kernel binary (copy to SD card)
  config.txt   - GPU configuration (copy to SD card)
  kernel8      - ELF file (for debugging)

Installation:
1. Format SD card with FAT32 partition
2. Download Pi firmware files from:
   https://github.com/raspberrypi/firmware/tree/master/boot
   Required: start.elf, fixup.dat
3. Copy to SD card:
   - start.elf
   - fixup.dat
   - config.txt
   - kernel8.img

The kernel will display a green border and title box on HDMI.
The ACT LED will blink patterns during boot.
